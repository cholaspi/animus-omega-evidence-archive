# Test 03 execution-source recovery notice

Date: 2026-09-10

The Test 03 execution-source provenance status is corrected from partial to
complete. The executed versions of
`resource_persistence_pilot/experiment.py` and
`tests/test_resource_persistence_pilot.py` were recovered from repository
history at commit `2c6af818c1cc26c8b00a2e83e6b21e11d1c7bb30`.

Each recovered file independently matches its expected SHA-256 in
`resource_persistence_pilot/executed_manifest.json`. The complete archive now
contains all 13 manifest-listed files, each checked byte-for-byte against that
executed manifest before packaging.

This correction changes only the source-provenance status. It does not change
the frozen execution manifest, protocol, seeds, outputs, reported statistics,
or the unsupported Test 03 result.