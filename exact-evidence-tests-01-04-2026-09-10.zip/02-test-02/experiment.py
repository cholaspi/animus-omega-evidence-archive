from __future__ import annotations

import json
import time
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .config import ExperimentConfig
from .counting import (
    extract_one_primitive_cycle,
    primitive_cycle_counts,
    rooted_closed_walk_counts,
    successors_from_mask,
)
from .graph import cyclic_scc_count


def _empty_cell() -> dict[str, object]:
    return {
        "rules": 0,
        "impossible": 0,
        "repeated_shorter_only": 0,
        "primitive_unique": 0,
        "multiple": 0,
        "rooted_unique": 0,
        "examples": [],
    }


def _plot_uniqueness(
    config: ExperimentConfig, summaries: dict[str, dict[str, object]], path: Path
) -> None:
    values = np.array(
        [
            [
                summaries[str(size)][str(period)]["primitive_unique_fraction"]
                for period in range(1, config.max_period + 1)
            ]
            for size in config.state_sizes
        ],
        dtype=float,
    )
    figure, axis = plt.subplots(figsize=(10, 4.8))
    image = axis.imshow(values, aspect="auto", cmap="viridis", vmin=0)
    axis.set_xticks(range(config.max_period), range(1, config.max_period + 1))
    axis.set_yticks(range(len(config.state_sizes)), config.state_sizes)
    axis.set_xlabel("Primitive period T")
    axis.set_ylabel("Number of states |X|")
    axis.set_title("Fraction of all labeled relations with exactly one primitive cycle")
    figure.colorbar(image, ax=axis, label="Exact uniqueness fraction")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def _plot_classification(
    config: ExperimentConfig, summaries: dict[str, dict[str, object]], path: Path
) -> None:
    figure, axes = plt.subplots(
        len(config.state_sizes), 1, figsize=(10, 3.2 * len(config.state_sizes)), sharex=True
    )
    periods = np.arange(1, config.max_period + 1)
    for axis, size in zip(np.atleast_1d(axes), config.state_sizes, strict=True):
        cells = [summaries[str(size)][str(period)] for period in periods]
        impossible = np.array([cell["impossible_fraction"] for cell in cells])
        repeated = np.array([cell["repeated_shorter_only_fraction"] for cell in cells])
        unique = np.array([cell["primitive_unique_fraction"] for cell in cells])
        multiple = np.array([cell["multiple_fraction"] for cell in cells])
        axis.stackplot(
            periods,
            impossible,
            repeated,
            unique,
            multiple,
            labels=(
                "No closed history",
                "Shorter cycles only",
                "One primitive story",
                "Multiple primitive stories",
            ),
            colors=("#7f8c8d", "#d9d9d9", "#2ca25f", "#756bb1"),
            alpha=0.9,
        )
        axis.set_ylim(0, 1)
        axis.set_ylabel(f"|X|={size}\nrule fraction")
        axis.grid(alpha=0.2)
    axes[0].legend(loc="upper right", ncol=2)
    axes[-1].set_xlabel("Loop period T")
    figure.suptitle("Exact classification of the complete binary-relation family")
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def run_experiment(
    config: ExperimentConfig | None = None,
    output_dir: Path = Path("self_closing_story/output"),
) -> dict[str, object]:
    config = config or ExperimentConfig()
    output_dir.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    raw: dict[int, dict[int, dict[str, object]]] = {
        size: {period: _empty_cell() for period in range(1, config.max_period + 1)}
        for size in config.state_sizes
    }
    structure = defaultdict(lambda: {"rules": 0, "unique": 0})

    for size in config.state_sizes:
        for mask in range(1 << (size * size)):
            successors = successors_from_mask(mask, size)
            rooted = rooted_closed_walk_counts(successors, config.max_period)
            exact_period, cycles = primitive_cycle_counts(rooted)
            cyclic_components = cyclic_scc_count(successors)
            edge_count = mask.bit_count()

            for period, (rooted_count, exact_count, cycle_count) in enumerate(
                zip(rooted, exact_period, cycles, strict=True), start=1
            ):
                cell = raw[size][period]
                cell["rules"] += 1
                if rooted_count == 0:
                    cell["impossible"] += 1
                elif cycle_count == 0:
                    cell["repeated_shorter_only"] += 1
                elif cycle_count == 1:
                    cell["primitive_unique"] += 1
                    examples = cell["examples"]
                    if len(examples) < config.max_examples_per_cell:
                        cycle = extract_one_primitive_cycle(successors, period)
                        if cycle is None:
                            raise AssertionError("Unique cycle could not be extracted")
                        examples.append(
                            {
                                "adjacency_mask": mask,
                                "edge_count": edge_count,
                                "cycle": list(cycle),
                                "rooted_closed_walks": rooted_count,
                                "exact_period_rooted_histories": exact_count,
                            }
                        )
                elif cycle_count > 1:
                    cell["multiple"] += 1
                if rooted_count == 1:
                    cell["rooted_unique"] += 1

                key = (size, period, cyclic_components)
                structure[key]["rules"] += 1
                structure[key]["unique"] += int(cycle_count == 1)

    summaries: dict[str, dict[str, object]] = {}
    for size in config.state_sizes:
        summaries[str(size)] = {}
        for period in range(1, config.max_period + 1):
            cell = raw[size][period]
            rules = int(cell["rules"])
            summaries[str(size)][str(period)] = {
                **cell,
                "impossible_fraction": cell["impossible"] / rules,
                "repeated_shorter_only_fraction": (
                    cell["repeated_shorter_only"] / rules
                ),
                "primitive_unique_fraction": cell["primitive_unique"] / rules,
                "multiple_fraction": cell["multiple"] / rules,
                "rooted_unique_fraction": cell["rooted_unique"] / rules,
            }

    conjecture_rows = []
    for size in config.state_sizes:
        for period in range(1, config.max_period + 1):
            one = structure[(size, period, 1)]
            many_rules = sum(
                structure[(size, period, count)]["rules"] for count in range(2, size + 1)
            )
            many_unique = sum(
                structure[(size, period, count)]["unique"] for count in range(2, size + 1)
            )
            conjecture_rows.append(
                {
                    "state_size": size,
                    "period": period,
                    "one_cyclic_scc_unique_fraction": (
                        one["unique"] / one["rules"] if one["rules"] else None
                    ),
                    "multiple_cyclic_scc_unique_fraction": (
                        many_unique / many_rules if many_rules else None
                    ),
                    "supports_preregistered_direction": (
                        True
                        if not many_rules
                        else one["unique"] / one["rules"] > many_unique / many_rules
                    ),
                }
            )

    results = {
        "experiment": "The Self-Closing Story",
        "config": config.to_dict(),
        "rule_family": (
            "every labeled binary relation on X, including empty and self-loop edges; "
            "families are reported separately by |X|"
        ),
        "primary_observable": (
            "number of primitive period-T cycles modulo temporal rotation"
        ),
        "count_definitions": {
            "W_T": "trace(M^T), rooted closed walks with period dividing T",
            "P_T": "Möbius-inverted rooted histories of minimal period exactly T",
            "C_T": "P_T / T, primitive cycles modulo temporal rotation",
        },
        "classification": {
            "impossible": "W_T = 0",
            "repeated_shorter_only": "W_T > 0 and C_T = 0",
            "primitive_unique": "C_T = 1",
            "multiple": "C_T > 1",
        },
        "preregistered_structural_conjecture": (
            "For fixed |X| and T, primitive uniqueness is more prevalent among "
            "rules with exactly one cyclic strongly connected component than among "
            "rules with multiple cyclic strongly connected components."
        ),
        "summaries": summaries,
        "structural_conjecture_results": conjecture_rows,
        "elapsed_seconds": time.perf_counter() - started,
        "scope_wall": (
            "Exact finite combinatorics only; no inference about physical time, "
            "cosmology, consciousness, meaning, or causal efficacy."
        ),
    }

    results_path = output_dir / "results.json"
    results_path.write_text(json.dumps(results, indent=2) + "\n")
    _plot_uniqueness(config, summaries, output_dir / "uniqueness_map.png")
    _plot_classification(config, summaries, output_dir / "classification_scaling.png")
    return results


def print_report(results: dict[str, object]) -> None:
    print("\nTHE SELF-CLOSING STORY — EXACT RESULTS")
    print("=" * 52)
    print(f"Rule family: {results['rule_family']}")
    for size, by_period in results["summaries"].items():
        rule_count = by_period["1"]["rules"]
        print(f"\n|X|={size}: {rule_count:,} relations")
        for period, cell in by_period.items():
            print(
                f"  T={period}: 0={cell['impossible']:,}, "
                f"shorter-only={cell['repeated_shorter_only']:,}, "
                f"1 primitive={cell['primitive_unique']:,}, "
                f"multiple={cell['multiple']:,}"
            )
    supported = sum(
        row["supports_preregistered_direction"]
        for row in results["structural_conjecture_results"]
    )
    total = len(results["structural_conjecture_results"])
    print(f"\nStructural conjecture supported in {supported}/{total} size-period cells.")
    print(f"Elapsed: {results['elapsed_seconds']:.3f} seconds")
    print("Results: self_closing_story/output/results.json")
    print(
        "Plots: self_closing_story/output/uniqueness_map.png, "
        "self_closing_story/output/classification_scaling.png"
    )
