#!/usr/bin/env python3
from self_closing_story.experiment import print_report, run_experiment


if __name__ == "__main__":
    print_report(run_experiment())
