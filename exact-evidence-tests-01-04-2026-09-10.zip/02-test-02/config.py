from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class ExperimentConfig:
    state_sizes: tuple[int, ...] = (2, 3, 4)
    max_period: int = 8
    max_examples_per_cell: int = 5

    def to_dict(self) -> dict[str, object]:
        data = asdict(self)
        data["state_sizes"] = list(self.state_sizes)
        return data
