# Pre-Run Methods Note — The Self-Closing Story

**Frozen:** 2026-09-09, before the first full rule-family sweep.

## Question

For a finite relational transition rule and loop period `T`, how many primitive
closed histories satisfy the local transition rule and the global periodic
boundary condition? When is there exactly one, after removing the arbitrary
choice of temporal starting point?

## Fixed family

For each labeled state space size `|X|` in `{2, 3, 4}`, enumerate every binary
relation `M ⊆ X × X`. This includes the empty relation, self-loops, deterministic
rules, reversible rules, and branching rules. There are respectively 16, 512,
and 65,536 rules. Families are never pooled across state size.

Loop periods are `T=1..8`. States remain labeled. The only quotient is temporal
rotation; spatial, label, reflection, and time-reversal symmetries are not
identified.

## Exact observables

- `W_T = trace(M^T)`: rooted closed walks, including repetitions of shorter
  cycles.
- `P_T = Σ_{d|T} μ(d) W_{T/d}`: rooted histories whose minimal period is exactly
  `T`.
- `C_T = P_T/T`: primitive period-`T` cycles modulo temporal rotation.

The primary classification is:

- impossible: `W_T=0`;
- shorter cycles only: `W_T>0` and `C_T=0`;
- primitive unique: `C_T=1`;
- multiple primitive stories: `C_T>1`.

`W_T=1` is reported separately because it means rooted uniqueness and generally
selects a fixed point, not a unique nontrivial story.

## Structural conjecture

For fixed `|X|` and `T`, primitive uniqueness is more prevalent among rules with
exactly one cyclic strongly connected component than among rules with multiple
cyclic strongly connected components. This is an exact descriptive comparison
over the complete family, not a sampled significance test.

## Computation and walls

All counts use Python arbitrary-precision integers. No training, Monte Carlo,
floating-point estimator, or statistical inference enters the counts.

The experiment establishes finite combinatorial existence, frequency, and graph
structure only. It does not test whether physical time loops, whether reality is
predetermined, or whether meaning, consciousness, or love has any causal role.
