from collections.abc import Sequence


def successors_from_mask(mask: int, n_states: int) -> tuple[tuple[int, ...], ...]:
    """Decode a row-major adjacency-matrix bit mask."""
    return tuple(
        tuple(
            target
            for target in range(n_states)
            if mask & (1 << (source * n_states + target))
        )
        for source in range(n_states)
    )


def rooted_closed_walk_counts(
    successors: Sequence[Sequence[int]], max_period: int
) -> list[int]:
    """Return trace(M^T), T=1..max_period, using Python integer arithmetic."""
    n_states = len(successors)
    counts = [0] * max_period
    for start in range(n_states):
        values = [0] * n_states
        values[start] = 1
        for period in range(max_period):
            following = [0] * n_states
            for source, value in enumerate(values):
                if value:
                    for target in successors[source]:
                        following[target] += value
            counts[period] += following[start]
            values = following
    return counts


def mobius(number: int) -> int:
    prime_count = 0
    remaining = number
    prime = 2
    while prime * prime <= remaining:
        if remaining % prime == 0:
            remaining //= prime
            prime_count += 1
            if remaining % prime == 0:
                return 0
            while remaining % prime == 0:
                remaining //= prime
        prime += 1
    if remaining > 1:
        prime_count += 1
    return -1 if prime_count % 2 else 1


def divisors(number: int) -> list[int]:
    return [candidate for candidate in range(1, number + 1) if number % candidate == 0]


def primitive_cycle_counts(rooted_counts: Sequence[int]) -> tuple[list[int], list[int]]:
    """Return exact-period rooted counts P_T and unrooted primitive cycles C_T."""
    exact_period: list[int] = []
    primitive_cycles: list[int] = []
    for period in range(1, len(rooted_counts) + 1):
        exact = sum(
            mobius(divisor) * rooted_counts[period // divisor - 1]
            for divisor in divisors(period)
        )
        if exact < 0 or exact % period:
            raise AssertionError("Möbius inversion produced an invalid cycle count")
        exact_period.append(exact)
        primitive_cycles.append(exact // period)
    return exact_period, primitive_cycles


def minimal_period(sequence: Sequence[int]) -> int:
    length = len(sequence)
    for candidate in divisors(length):
        if all(sequence[index] == sequence[index % candidate] for index in range(length)):
            return candidate
    return length


def canonical_rotation(sequence: Sequence[int]) -> tuple[int, ...]:
    values = tuple(sequence)
    rotations = [values[index:] + values[:index] for index in range(len(values))]
    return min(rotations)


def extract_one_primitive_cycle(
    successors: Sequence[Sequence[int]], period: int
) -> tuple[int, ...] | None:
    """Find one primitive period-T cycle and return its canonical rotation."""

    def search(start: int, path: list[int]) -> tuple[int, ...] | None:
        if len(path) == period:
            if start in successors[path[-1]] and minimal_period(path) == period:
                return canonical_rotation(path)
            return None
        for target in successors[path[-1]]:
            path.append(target)
            found = search(start, path)
            path.pop()
            if found is not None:
                return found
        return None

    for start in range(len(successors)):
        found = search(start, [start])
        if found is not None:
            return found
    return None
