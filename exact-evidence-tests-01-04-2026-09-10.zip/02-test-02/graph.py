from collections.abc import Sequence


def strongly_connected_components(
    successors: Sequence[Sequence[int]],
) -> list[tuple[int, ...]]:
    index = 0
    indices: dict[int, int] = {}
    lowlinks: dict[int, int] = {}
    stack: list[int] = []
    on_stack: set[int] = set()
    components: list[tuple[int, ...]] = []

    def visit(vertex: int) -> None:
        nonlocal index
        indices[vertex] = index
        lowlinks[vertex] = index
        index += 1
        stack.append(vertex)
        on_stack.add(vertex)

        for target in successors[vertex]:
            if target not in indices:
                visit(target)
                lowlinks[vertex] = min(lowlinks[vertex], lowlinks[target])
            elif target in on_stack:
                lowlinks[vertex] = min(lowlinks[vertex], indices[target])

        if lowlinks[vertex] == indices[vertex]:
            component: list[int] = []
            while True:
                member = stack.pop()
                on_stack.remove(member)
                component.append(member)
                if member == vertex:
                    break
            components.append(tuple(sorted(component)))

    for vertex in range(len(successors)):
        if vertex not in indices:
            visit(vertex)
    return components


def cyclic_scc_count(successors: Sequence[Sequence[int]]) -> int:
    total = 0
    for component in strongly_connected_components(successors):
        if len(component) > 1:
            total += 1
        elif component[0] in successors[component[0]]:
            total += 1
    return total
