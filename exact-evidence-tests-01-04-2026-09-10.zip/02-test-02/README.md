# The Self-Closing Story

An exactly enumerable test of when a finite relational rule admits zero, one,
or multiple self-consistent closed histories.

Run:

```bash
python run_self_closing_story.py
```

Outputs:

- `output/results.json`: complete configuration, exact classifications,
  structural-conjecture results, and representative unique cycles.
- `output/uniqueness_map.png`: exact primitive-uniqueness fraction by state
  size and period.
- `output/classification_scaling.png`: impossible/unique/multiple fractions
  across period and state size.

The experiment intentionally distinguishes `trace(M^T)`, which counts rooted
closed walks, from primitive cycles modulo temporal rotation. See `METHODS.md`
for the frozen definitions and claim boundaries.
