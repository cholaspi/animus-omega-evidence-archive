# Verify the Tests 01-04 evidence archive

This archive was assembled on 2026-09-10. No Replit tools are required.

From the extracted archive root:

```sh
sha256sum -c SHA256SUMS
```

On macOS, where `sha256sum` is not installed:

```sh
shasum -a 256 -c SHA256SUMS
```

Before extraction, verify the downloaded ZIP from the directory containing it:

```sh
sha256sum -c exact-evidence-tests-01-04-2026-09-10.zip.sha256
```

Every path in `SHA256SUMS` is relative to the extracted archive root. The
`MANIFEST.json` record maps each archived file to its canonical project source
and records the source digest checked before packaging.
