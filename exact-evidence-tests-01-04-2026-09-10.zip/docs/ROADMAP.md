# Animus Omega roadmap

This is an auditable engineering plan. It is not a promise of evidence about
the universe. Every stage must produce inspectable artifacts, pass declared
acceptance checks, and stop when its evidence requirements are not met.

## Stage 0: Record and boundary

**Status:** Current

**Purpose:** Preserve the completed evidence and separate it from proposed
engineering and optional cosmology.

**Deliverables**

- Theory and claims ledger
- Simulator specification
- Public methods, deviations, and release manifests
- OSF retrospective-registration package
- Human and AI contribution policies

**Acceptance**

Every test has an explicit status, reproducible artifacts where available, and
visible provenance limitations. Missing or conflicting evidence status blocks
new claims.

## Stage 1: Minimal simulator foundation

**Purpose:** Prove that the combined architecture can be implemented and
audited before attempting a large world.

### Stage 1A: Core world contracts

Define the authoritative trunk, event schema, world clock, identities,
relationships, obligations, unresolved events, causal dependencies, bounded
views, dump records, merge rules, and cost accounting.

**Acceptance**

- Schemas are versioned and machine-readable.
- Every authoritative mutation has provenance.
- Protected entries cannot disappear without a typed loss record.
- Conflicting writes are rejected or resolved by a frozen deterministic rule.

### Stage 1B: Deterministic world MVP

Implement one trunk, two deterministic regions, a small population, a
versioned protected ledger, bounded local views, dump residuals,
deterministic merge and still operations, checkpoints, and cost counters.

**Acceptance**

- Identical seeds and inputs produce identical state and observation digests.
- Exact checkpoint replay succeeds over the declared horizon.
- Tests cover stale writes, duplicate events, conflicts, identity loss, and
  protected-ledger violations.
- The run publishes its schema, seed, command, fixtures, outputs, and manifest.

This stage establishes buildability only.

### Stage 1C: Research council workspace

Create the internal workspace that coordinates human and AI contributors.
The first version must operate on real project records rather than placeholder
activity.

**Workspace responsibilities**

- Display proposed questions, protocols, assignments, and agent disclosures.
- Track isolated implementations, critic findings, validation results, and
  unresolved disagreements.
- Connect claims to supporting and contradicting artifacts.
- Show provenance manifests, checksums, deviations, and experiment costs.
- Require human approval before freezing a protocol, opening reserved seeds,
  accepting a claim, merging authoritative simulator changes, classifying an
  independent replication, or publishing a record.

**Acceptance**

- Agents can submit structured proposals and evidence without directly
  modifying accepted claims.
- Human decisions are attributable and reversible before publication.
- Failed and rejected contributions remain visible.
- No agent can approve its own scientific conclusion.

### Stage 1D: World simulator dashboard

Build a functional control and observation surface for the deterministic MVP.

**Dashboard responsibilities**

- Display authoritative trunk state, world time, regions, and inhabitants.
- Inspect identities, relationships, obligations, unresolved events, and
  causal dependencies in the protected ledger.
- Show proposed, accepted, rejected, and conflicting events.
- Inspect dumps, reconstruction assumptions, checkpoints, and replay results.
- Report memory, CPU, storage, merge, and reconstruction costs.

**Acceptance**

- Every displayed value comes from the running simulator or its immutable run
  artifacts.
- Dashboard actions cannot bypass event validation or human approval gates.
- A user can trace a visible world change back to its source event and
  provenance record.

## Stage 2: Bounded payload benchmark

Compare trunk-only, split-without-dump, dump-only, and split/dump/merge
architectures on frozen finite workloads. Predeclare payload fidelity, memory,
CPU, storage, dump, merge, and reconstruction metrics.

**Acceptance**

- All inputs, outputs, failures, costs, and exclusions are published.
- The benchmark produces a complete comparison table.
- A clean independent rerun is attempted.
- No winner is generalized beyond the tested workloads.

## Stage 3: AI research council automation

Allow specialist agents to propose protocols, build isolated implementations,
generate tests, search for counterexamples, audit provenance, and prepare claim
proposals.

**Acceptance**

- Agent roles, tools, instructions, inputs, outputs, and model disclosures are
  recorded.
- Independent implementations do not share implementation details during
  their isolated phase.
- AI-assisted work is not labeled independent replication solely because it
  used another model, agent, or prompt.
- Reserved execution and publication remain human-authorized.
- Compute and tool budgets are enforced.

## Stage 4: Narrative closure benchmark

Specify forward and return constraints, causal continuity, and the
inhabitant-visible narrative criterion. Test finite graphs and histories with
known positive and negative controls.

**Acceptance**

- The benchmark distinguishes recurrence from mutual temporal constraint.
- Seams, failures, ledger costs, and conflicting histories are reported.
- A passing result supports only internal simulated narrative closure under
  the frozen model.

The closure constraint is currently untested.

## Stage 5: Independent replication and registration

Have a separately accountable reviewer or team run the frozen benchmark in an
independently controlled environment. Deposit prospective protocols and
results through OSF Registration, while the repository and website remain the
active collaboration locations.

A mismatch requires a deviation record, not a quiet correction.

## Evidence guardrails

Tests 01 through 04 remain retrospective in the current OSF record. Test 03
failed its support criterion. Test 04 Revision 2 is limited to exact replay in
its fixed model and tested horizon. Revision 1 is aborted.

No roadmap stage licenses claims about physical recurrence, consciousness,
subjective continuity, cosmology, entropy removal, or universe-scale resource
savings.