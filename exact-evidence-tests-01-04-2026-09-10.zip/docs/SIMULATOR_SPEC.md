# Animus Omega simulator specification

**Status:** design specification. This is a buildable pattern, not a result of
the completed tests. It does not claim that the physical universe, a mind, or
consciousness uses this architecture.

## Purpose and boundary

The simulator studies whether a bounded executable can preserve a specified
world payload while it splits work, discards detail, and reunites work. The
payload is operational: identities, relationships, obligations, unresolved
events, and plot phase. “Narrative” means state and dependency bookkeeping,
not subjective experience.

The proposed narrative-closure boundary is an **untested internal constraint**:
an ending-to-beginning pathway must supply the conditions required by the
beginning, while the boundary remains an event in one continuous simulated
history. This is not a physical time loop, backwards causation, consciousness,
or evidence about the universe.

## State model

### Trunk

The trunk is the sole authoritative state:

- a monotonic world clock and configuration;
- entity and identity store;
- relation ledger (edges, obligations, ownership, and provenance);
- unresolved-event and causal-dependency ledger;
- plot-state ledger, including open arcs and required next-scene conditions;
- resource accounting and versioned schema.

Threads never commit directly to the trunk. Every mutation is an event with
source thread, logical time, input version, and deterministic conflict
metadata.

### Observer and region threads

At split, the scheduler creates observer, region, or inhabitant threads. Each
receives a versioned partial view and a bounded working buffer. A thread may
read only its view, emit proposed events, and maintain local microstate. It
does not receive an implicit full copy of the world. Views must identify their
omissions and stale reads.

### Protected narrative ledger

The protected ledger is the minimum state that may not be silently dropped:
stable identity mappings; relation edges and their provenance; obligations and
promises; unresolved events; plot phase and open dependencies; and the
conditions marked as required for a future scene or closure boundary. Each
entry has a schema version, owner, last authoritative update, and retention
reason. A dump may reject an entry only through an explicit, recorded policy.

### Dump

`dump(thread_state, policy)` produces a residual plus an audit record. It may
unload inactive microstate or summarize it, but must report discarded fields,
retained fields, lossy transforms, and reconstruction assumptions. Dump cost
includes serialization, summary computation, storage, I/O, and information
loss. A successful dump is not proof of fidelity.

### Merge and still

`merge(residuals, trunk_version)` synchronizes threads at a barrier, validates
versions, orders events deterministically, applies the declared conflict rule,
updates the trunk, and records discarded detail. The default conflict rule is
“reject ambiguous writes”; alternatives require a versioned specification.

`still` is a merge with new event intake paused: threads drain or cancel
according to policy, residuals are committed, and the trunk emits a quiet
checkpoint. Stillness is an engineering state, not a claim about meditation,
love, or physics.

## Cost model

Every run reports wall-clock time separately from semantic outcomes and
accounts for thread CPU, memory and retained context, view construction,
serialization, dump storage, merge/barrier time, reconstruction, conflict
resolution, and discarded information. Resource comparisons must define the
budget and task fidelity in advance. A torus, compression, or state reuse
does not remove compute, storage, or thermodynamic costs.

## Invariants and acceptance checks

1. Only the trunk can authoritatively advance world time or protected-ledger
   entries.
2. Every committed event has deterministic provenance and is applied once.
3. Split/merge preserves identity keys and ledger referential integrity.
4. No protected entry disappears without a typed loss record and policy.
5. Conflicting writes are rejected or resolved by the frozen rule, never by
   iteration order.
6. Replay from an identical trunk, residual set, configuration, and seed is
   identical within the declared semantic state and observation horizon.
7. Dump and merge are auditable: input/output digests, costs, losses, and
   conflicts are recorded.
8. Narrative closure, if implemented, must satisfy both forward causal
   continuity and the explicit return constraint; it is not inferred from a
   cycle alone.

## Failure modes

Test and report at least: stale-view writes; duplicate or lost events; broken
identity joins; contradictory relations; unresolved merge conflicts; ledger
overflow; summary hallucination or under-specification; reconstruction drift;
unbounded thread or buffer growth; deadlock at the barrier; nondeterministic
ordering; hidden full-world copies; resource-budget overruns; and a closure
boundary that exposes a seam or fails to supply its declared initial
conditions. Failure is informative and must not be relabeled as fidelity.

## Evidence boundary

The public record describes this architecture as a proposed synthesis. Tests
01–04 are separate operational studies; they do not validate the combined
simulator, its narrative closure, comparative fidelity, information creation,
or a physical-universe claim.