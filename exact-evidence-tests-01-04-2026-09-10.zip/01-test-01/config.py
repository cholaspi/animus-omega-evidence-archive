from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class PilotConfig:
    seed: int = 20260909
    n_cells: int = 8
    n_agents: int = 3
    n_targets: int = 3
    episode_steps: int = 16
    cycles_per_rollout: int = 50
    train_episodes: int = 240
    learning_rate: float = 3e-3
    hidden_size: int = 64
    entropy_bonus: float = 0.01
    auxiliary_weight: float = 0.15
    measure_rollouts: int = 64
    null_seeds: int = 1024
    null_training_pairs: int = 10
    reset_block_sizes: list[int] = field(default_factory=lambda: [2, 3, 4, 5, 8])
    output_dir: str = "pilot/output"

    @property
    def target_cells(self) -> tuple[int, ...]:
        # Spaced targets make the completion bonus require actual coverage.
        return tuple((i * self.n_cells) // self.n_targets for i in range(self.n_targets))

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["target_cells"] = list(self.target_cells)
        return result

    def output_path(self) -> Path:
        path = Path(self.output_dir)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def validate(self) -> None:
        if self.n_agents != 3 or self.n_cells != 8:
            raise ValueError("The pilot intentionally supports exactly N=3 agents on 8 cells.")
        if self.cycles_per_rollout < 50:
            raise ValueError("cycles_per_rollout must be at least 50.")
        if self.null_seeds < 1000:
            raise ValueError("null_seeds must be at least 1000.")
        if self.null_training_pairs < 4:
            raise ValueError("null_training_pairs must be at least 4.")
        if self.null_seeds != 2**self.null_training_pairs:
            raise ValueError(
                "null_seeds must enumerate every paired sign assignment exactly."
            )
        if any(b < 2 or b > 9 for b in self.reset_block_sizes):
            raise ValueError("Reset block sizes must be between 2 and the 9-bit state width.")
