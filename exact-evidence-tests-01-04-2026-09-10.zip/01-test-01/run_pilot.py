from __future__ import annotations

import argparse

from pilot.config import PilotConfig
from pilot.experiment import print_acceptance_report, run


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the exact tiny-regime multi-agent reset-persistence pilot."
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Developer smoke run only; intentionally below preregistered sample counts.",
    )
    parser.add_argument(
        "--output-dir",
        default="pilot/output",
        help="Directory for results.json and plots.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = PilotConfig(output_dir=args.output_dir)
    if args.quick:
        config.train_episodes = 12
        config.cycles_per_rollout = 3
        config.null_seeds = 2
        config.null_training_pairs = 1
        config.reset_block_sizes = [2, 4, 8]
    results = run(config, allow_small_debug_run=args.quick)
    print_acceptance_report(results)


if __name__ == "__main__":
    main()
