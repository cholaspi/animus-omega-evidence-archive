from __future__ import annotations

import numpy as np


class RingCoverageEnvironment:
    """An 8-cell cooperative coverage task with strictly local observations."""

    def __init__(
        self,
        n_cells: int = 8,
        n_agents: int = 3,
        target_cells: tuple[int, ...] = (0, 2, 5),
    ) -> None:
        self.n_cells = n_cells
        self.n_agents = n_agents
        self.target_cells = frozenset(target_cells)
        self.observation_size = n_cells + 2
        self.n_actions = 3  # left, right, stay

    def observation(self, state: np.ndarray, agent: int) -> np.ndarray:
        state = np.asarray(state, dtype=np.int64)
        own_position = int(state[agent])
        observation = np.zeros(self.observation_size, dtype=np.float32)
        observation[own_position] = 1.0
        left = (own_position - 1) % self.n_cells
        right = (own_position + 1) % self.n_cells
        observation[self.n_cells] = float(np.any(state == left))
        observation[self.n_cells + 1] = float(np.any(state == right))
        return observation

    def observations(self, state: np.ndarray) -> np.ndarray:
        return np.stack(
            [self.observation(state, agent) for agent in range(self.n_agents)]
        )

    def transition(self, state: np.ndarray, actions: np.ndarray) -> np.ndarray:
        state = np.asarray(state, dtype=np.int64)
        actions = np.asarray(actions, dtype=np.int64)
        delta = np.where(actions == 0, -1, np.where(actions == 1, 1, 0))
        return (state + delta) % self.n_cells

    def reward(self, state: np.ndarray) -> float:
        target_occupancy = sum(float(position in self.target_cells) for position in state)
        covered_targets = len(set(int(position) for position in state) & self.target_cells)
        completion_bonus = 2.0 if covered_targets == len(self.target_cells) else 0.0
        return target_occupancy + completion_bonus
