from __future__ import annotations

import math
from typing import Iterable

import numpy as np


def entropy_from_counts(counts: np.ndarray) -> float:
    """Shannon entropy in nats from non-negative discrete counts."""
    counts = np.asarray(counts, dtype=np.float64)
    total = counts.sum()
    if total <= 0:
        return 0.0
    probabilities = counts[counts > 0] / total
    return float(-(probabilities * np.log(probabilities)).sum())


def entropy(values: Iterable[int], alphabet_size: int | None = None) -> float:
    values_array = np.asarray(list(values), dtype=np.int64)
    if values_array.size == 0:
        return 0.0
    size = int(alphabet_size or (values_array.max() + 1))
    return entropy_from_counts(np.bincount(values_array, minlength=size))


def mutual_information_from_probabilities(joint: np.ndarray) -> float:
    """Exact MI from a complete joint probability table, with no sampling."""
    table = np.asarray(joint, dtype=np.float64)
    if table.ndim != 2:
        raise ValueError("joint must be a two-dimensional probability table")
    total = table.sum()
    if total <= 0:
        return 0.0
    table = table / total
    px = table.sum(axis=1, keepdims=True)
    py = table.sum(axis=0, keepdims=True)
    nonzero = table > 0
    return float(
        (table[nonzero] * np.log(table[nonzero] / (px @ py)[nonzero])).sum()
    )


def mutual_information(
    x: Iterable[int],
    y: Iterable[int],
    x_alphabet_size: int,
    y_alphabet_size: int,
    miller_madow: bool = True,
) -> float:
    """MI over the explicitly enumerated x/y alphabets.

    The joint table is a dense x_alphabet_size by y_alphabet_size table.
    For the pilot's joint state, that is exactly 512 x 512 cells; no
    k-nearest-neighbor or continuous approximation is used.
    """
    x_array = np.asarray(list(x), dtype=np.int64)
    y_array = np.asarray(list(y), dtype=np.int64)
    if x_array.shape != y_array.shape:
        raise ValueError("x and y must have the same number of samples")
    if x_array.size == 0:
        return 0.0
    if np.any((x_array < 0) | (x_array >= x_alphabet_size)):
        raise ValueError("x contains a value outside its declared alphabet")
    if np.any((y_array < 0) | (y_array >= y_alphabet_size)):
        raise ValueError("y contains a value outside its declared alphabet")

    table = np.zeros((x_alphabet_size, y_alphabet_size), dtype=np.int64)
    np.add.at(table, (x_array, y_array), 1)
    plugin = mutual_information_from_probabilities(table)
    if not miller_madow:
        return plugin

    # Miller-Madow correction for I(X;Y) in nats:
    # (number of occupied joint cells - occupied X cells - occupied Y cells + 1)/(2n)
    occupied_joint = int(np.count_nonzero(table))
    occupied_x = int(np.count_nonzero(table.sum(axis=1)))
    occupied_y = int(np.count_nonzero(table.sum(axis=0)))
    correction = (occupied_joint - occupied_x - occupied_y + 1) / (2.0 * x_array.size)
    return float(plugin + correction)


def joint_state_code(state: Iterable[int], n_cells: int = 8) -> int:
    values = tuple(int(value) for value in state)
    code = 0
    for value in values:
        if not 0 <= value < n_cells:
            raise ValueError("state position outside ring")
        code = code * n_cells + value
    return code


def decode_joint_state(code: int, n_agents: int = 3, n_cells: int = 8) -> np.ndarray:
    if not 0 <= code < n_cells**n_agents:
        raise ValueError("joint state code outside enumerated state space")
    result = np.zeros(n_agents, dtype=np.int64)
    remainder = int(code)
    for index in range(n_agents - 1, -1, -1):
        result[index] = remainder % n_cells
        remainder //= n_cells
    return result


def joint_state_codes(states: np.ndarray, n_cells: int = 8) -> np.ndarray:
    values = np.asarray(states, dtype=np.int64)
    if values.ndim != 2:
        raise ValueError("states must have shape [samples, agents]")
    codes = np.zeros(values.shape[0], dtype=np.int64)
    for column in values.T:
        codes = codes * n_cells + column
    return codes


def relational_persistence(
    end_states: np.ndarray,
    seed_states: np.ndarray,
    n_cells: int = 8,
    miller_madow: bool = True,
) -> dict[str, float]:
    """Compute P_rel using exact enumeration of the 512 joint states."""
    ends = np.asarray(end_states, dtype=np.int64)
    seeds = np.asarray(seed_states, dtype=np.int64)
    if ends.shape != seeds.shape or ends.shape[1] != 3:
        raise ValueError("end_states and seed_states must both have shape [samples, 3]")
    end_codes = joint_state_codes(ends, n_cells)
    seed_codes = joint_state_codes(seeds, n_cells)
    joint_mi = mutual_information(
        end_codes, seed_codes, n_cells**3, n_cells**3, miller_madow=miller_madow
    )
    self_mi = [
        mutual_information(
            ends[:, index],
            seeds[:, index],
            n_cells,
            n_cells,
            miller_madow=miller_madow,
        )
        for index in range(ends.shape[1])
    ]
    return {
        "joint_mi_nats": joint_mi,
        "self_mi_nats": float(sum(self_mi)),
        "self_mi_by_agent_nats": [float(value) for value in self_mi],
        "p_rel_nats": float(joint_mi - sum(self_mi)),
        "n_samples": int(len(ends)),
        "joint_alphabet_size": int(n_cells**3),
        "mi_method": "dense exact plug-in over 512 joint states + Miller-Madow",
    }


def relational_persistence_from_joint_distribution(
    end_seed_joint: np.ndarray,
    n_cells: int = 8,
) -> dict[str, float | list[float] | int | str]:
    """Ground-truth P_rel from a complete 512 x 512 probability table.

    Every joint-state pair is represented explicitly. This function receives
    probabilities, not samples, and therefore applies no finite-sample
    estimator or bias correction.
    """
    joint = np.asarray(end_seed_joint, dtype=np.float64)
    n_states = n_cells**3
    if joint.shape != (n_states, n_states):
        raise ValueError(f"expected a {(n_states, n_states)} probability table")
    total = joint.sum()
    if total <= 0:
        raise ValueError("joint probability table has no mass")
    joint = joint / total
    joint_mi = mutual_information_from_probabilities(joint)
    decoded = np.stack(
        [decode_joint_state(code, n_agents=3, n_cells=n_cells) for code in range(n_states)]
    )
    self_values: list[float] = []
    for agent in range(3):
        projection = np.zeros((n_states, n_cells), dtype=np.float64)
        projection[np.arange(n_states), decoded[:, agent]] = 1.0
        agent_joint = projection.T @ joint @ projection
        self_values.append(mutual_information_from_probabilities(agent_joint))
    return {
        "joint_mi_nats": float(joint_mi),
        "self_mi_nats": float(sum(self_values)),
        "self_mi_by_agent_nats": [float(value) for value in self_values],
        "p_rel_nats": float(joint_mi - sum(self_values)),
        "joint_alphabet_size": n_states,
        "joint_table_shape": [n_states, n_states],
        "mi_method": "exact full-probability enumeration; no sampled estimator",
    }


def run_known_mi_check() -> dict[str, float]:
    """Hand-checkable test: a fair bit copied perfectly has I(X;Y)=ln(2)."""
    exact = mutual_information_from_probabilities(
        np.array([[0.5, 0.0], [0.0, 0.5]], dtype=np.float64)
    )
    expected = math.log(2.0)
    error = abs(exact - expected)
    if error > 1e-9:
        raise AssertionError(f"analytic MI check failed: error={error}")
    return {
        "computed_nats": float(exact),
        "analytic_nats": float(expected),
        "absolute_error_nats": float(error),
    }
