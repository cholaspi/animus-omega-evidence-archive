from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Literal

import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical

from .environment import RingCoverageEnvironment


Regime = Literal["isolated", "coupled"]


class SharedPolicy(nn.Module):
    """One shared MLP, with agent indication and a feedback auxiliary head."""

    def __init__(
        self,
        observation_size: int,
        n_agents: int,
        n_cells: int,
        hidden_size: int = 64,
    ) -> None:
        super().__init__()
        self.n_agents = n_agents
        self.n_cells = n_cells
        self.aux_size = n_agents * n_cells
        input_size = observation_size + n_agents + self.aux_size
        self.feature = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
        )
        self.action_head = nn.Linear(hidden_size, 3)
        self.aux_head = nn.Linear(
            observation_size + n_agents, n_agents * n_cells
        )

    def forward(
        self, observations: torch.Tensor, agent_ids: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        identity = torch.nn.functional.one_hot(
            agent_ids, num_classes=self.n_agents
        ).float()
        base = torch.cat([observations, identity], dim=-1)
        aux_logits = self.aux_head(base).view(-1, self.n_agents, self.n_cells)
        aux_probabilities = torch.softmax(aux_logits, dim=-1).reshape(
            -1, self.aux_size
        )
        features = self.feature(torch.cat([base, aux_probabilities], dim=-1))
        return self.action_head(features), aux_logits

    def action_from_aux(
        self,
        observations: torch.Tensor,
        agent_ids: torch.Tensor,
        aux_probabilities: torch.Tensor,
    ) -> torch.Tensor:
        identity = torch.nn.functional.one_hot(
            agent_ids, num_classes=self.n_agents
        ).float()
        base = torch.cat([observations, identity], dim=-1)
        if aux_probabilities.ndim == 3:
            aux_probabilities = aux_probabilities.reshape(
                aux_probabilities.shape[0], -1
            )
        features = self.feature(torch.cat([base, aux_probabilities], dim=-1))
        return self.action_head(features)


def _set_torch_seed(seed: int) -> None:
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(1)


def train_policy(
    regime: Regime,
    env: RingCoverageEnvironment,
    seed: int,
    episodes: int,
    learning_rate: float,
    hidden_size: int,
    entropy_bonus: float,
    auxiliary_weight: float,
    episode_steps: int,
) -> tuple[SharedPolicy, list[float]]:
    _set_torch_seed(seed)
    model = SharedPolicy(
        env.observation_size, env.n_agents, env.n_cells, hidden_size
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    generator = np.random.default_rng(seed)
    agent_ids = torch.arange(env.n_agents, dtype=torch.long)
    rewards_log: list[float] = []

    for _ in range(episodes):
        state = generator.integers(0, env.n_cells, size=env.n_agents)
        log_prob_steps: list[torch.Tensor] = []
        entropy_steps: list[torch.Tensor] = []
        auxiliary_losses: list[torch.Tensor] = []
        rewards: list[float] = []

        for _step in range(episode_steps):
            observations = torch.from_numpy(env.observations(state))
            action_logits, auxiliary_logits = model(observations, agent_ids)
            action_distribution = Categorical(logits=action_logits)
            actions = action_distribution.sample()
            next_state = env.transition(state, actions.detach().numpy())

            if regime == "coupled":
                targets = torch.from_numpy(
                    np.repeat(next_state[None, :], env.n_agents, axis=0)
                ).long()
            else:
                # The filler head predicts the acting agent's own current
                # position in every slot; it contains no partner information.
                targets = torch.from_numpy(
                    np.repeat(state[:, None], env.n_agents, axis=1)
                ).long()
            auxiliary_losses.append(
                torch.nn.functional.cross_entropy(
                    auxiliary_logits.reshape(-1, env.n_cells), targets.reshape(-1)
                )
            )
            log_prob_steps.append(action_distribution.log_prob(actions).mean())
            entropy_steps.append(action_distribution.entropy().mean())
            rewards.append(env.reward(next_state))
            state = next_state

        returns = np.zeros(len(rewards), dtype=np.float32)
        running = 0.0
        for index in range(len(rewards) - 1, -1, -1):
            running = rewards[index] + 0.97 * running
            returns[index] = running
        returns = (returns - returns.mean()) / (returns.std() + 1e-6)
        policy_loss = -(torch.stack(log_prob_steps) * torch.from_numpy(returns)).mean()
        aux_loss = torch.stack(auxiliary_losses).mean()
        entropy_loss = torch.stack(entropy_steps).mean()
        loss = policy_loss + auxiliary_weight * aux_loss - entropy_bonus * entropy_loss
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        rewards_log.append(float(np.mean(rewards)))

    model.eval()
    return model, rewards_log


@dataclass
class FrozenPolicy:
    """A frozen policy compiled to tables over all 512 measured joint states."""

    regime: Regime
    env: RingCoverageEnvironment
    model: SharedPolicy
    action_table: np.ndarray
    shuffled_action_table: np.ndarray
    partner_permutations: list[tuple[int, ...]]
    ablation_mean_abs_change: float
    ablation_max_abs_change: float
    forward_compile_max_abs_error: float

    @classmethod
    def compile(
        cls, regime: Regime, env: RingCoverageEnvironment, model: SharedPolicy
    ) -> "FrozenPolicy":
        # A pattern contains one swap/no-swap bit per acting agent. Each swap
        # exchanges only that actor's two partner slots and leaves its own slot
        # untouched.
        permutations = list(itertools.product((0, 1), repeat=env.n_agents))
        n_states = env.n_cells ** env.n_agents
        action_table = np.zeros((n_states, env.n_agents, 3), dtype=np.float64)
        shuffled_table = np.zeros(
            (n_states, env.n_agents, len(permutations), 3), dtype=np.float64
        )
        ids = torch.arange(env.n_agents, dtype=torch.long)
        consistency_errors: list[float] = []
        with torch.inference_mode():
            for code in range(n_states):
                state = _decode_code(code, env.n_agents, env.n_cells)
                observations = torch.from_numpy(env.observations(state))
                action_logits, aux_logits = model(observations, ids)
                auxiliary = torch.softmax(aux_logits, dim=-1)
                normal = torch.softmax(
                    model.action_from_aux(observations, ids, auxiliary), dim=-1
                ).numpy()
                forward_probabilities = torch.softmax(action_logits, dim=-1).numpy()
                consistency_errors.append(
                    float(np.max(np.abs(normal - forward_probabilities)))
                )
                action_table[code] = normal

                for permutation_index, permutation in enumerate(permutations):
                    if regime == "coupled":
                        permuted = auxiliary.clone()
                        for actor, swap_partners in enumerate(permutation):
                            if swap_partners:
                                partners = [
                                    index
                                    for index in range(env.n_agents)
                                    if index != actor
                                ]
                                permuted[actor, partners] = permuted[
                                    actor, list(reversed(partners))
                                ]
                    else:
                        permuted = auxiliary
                    shuffled_table[code, :, permutation_index] = torch.softmax(
                        model.action_from_aux(observations, ids, permuted), dim=-1
                    ).numpy()

        # Ablation: replace only partner feedback with uniform predictions,
        # while leaving each actor's own-state feedback unchanged.
        # This must measurably move the action distribution in the coupled
        # regime, otherwise the supposed coupling variable is behaviorally inert.
        ablation_differences: list[np.ndarray] = []
        if regime == "coupled":
            with torch.inference_mode():
                for code in range(n_states):
                    state = _decode_code(code, env.n_agents, env.n_cells)
                    observations = torch.from_numpy(env.observations(state))
                    _, aux_logits = model(observations, ids)
                    normal_aux = torch.softmax(aux_logits, dim=-1)
                    uniform_aux = normal_aux.clone()
                    for actor in range(env.n_agents):
                        for predicted_agent in range(env.n_agents):
                            if predicted_agent != actor:
                                uniform_aux[actor, predicted_agent] = (
                                    1.0 / env.n_cells
                                )
                    normal = torch.softmax(
                        model.action_from_aux(observations, ids, normal_aux), dim=-1
                    ).numpy()
                    ablated = torch.softmax(
                        model.action_from_aux(observations, ids, uniform_aux), dim=-1
                    ).numpy()
                    ablation_differences.append(np.abs(normal - ablated))
            differences = np.concatenate(ablation_differences)
            mean_change = float(differences.mean())
            max_change = float(differences.max())
            if mean_change <= 1e-6:
                raise AssertionError(
                    "coupled partner-prediction ablation did not change behavior"
                )
        else:
            mean_change = 0.0
            max_change = 0.0
        consistency_error = max(consistency_errors)
        if consistency_error > 1e-7:
            raise AssertionError(
                "compiled action probabilities differ from the trained forward path: "
                f"max error={consistency_error}"
            )

        return cls(
            regime=regime,
            env=env,
            model=model,
            action_table=action_table,
            shuffled_action_table=shuffled_table,
            partner_permutations=permutations,
            ablation_mean_abs_change=mean_change,
            ablation_max_abs_change=max_change,
            forward_compile_max_abs_error=consistency_error,
        )

    def action_probabilities(
        self,
        state: np.ndarray,
        partner_shuffle: bool = False,
        permutation_index: int | None = None,
    ) -> np.ndarray:
        code = _state_code(state, self.env.n_cells)
        if not partner_shuffle or self.regime == "isolated":
            return self.action_table[code]
        if permutation_index is None:
            return self.shuffled_action_table[code].mean(axis=1)
        return self.shuffled_action_table[code, :, permutation_index]

    def sample_actions(
        self,
        state: np.ndarray,
        rng: np.random.Generator,
        partner_shuffle: bool = False,
    ) -> np.ndarray:
        permutation_index = None
        if partner_shuffle and self.regime == "coupled":
            permutation_index = int(rng.integers(len(self.partner_permutations)))
        probabilities = self.action_probabilities(
            state, partner_shuffle=partner_shuffle, permutation_index=permutation_index
        )
        return np.asarray(
            [rng.choice(3, p=probabilities[agent]) for agent in range(self.env.n_agents)],
            dtype=np.int64,
        )


def _state_code(state: np.ndarray, n_cells: int) -> int:
    code = 0
    for position in np.asarray(state, dtype=np.int64):
        code = code * n_cells + int(position)
    return code


def _decode_code(code: int, n_agents: int, n_cells: int) -> np.ndarray:
    result = np.zeros(n_agents, dtype=np.int64)
    remainder = code
    for index in range(n_agents - 1, -1, -1):
        result[index] = remainder % n_cells
        remainder //= n_cells
    return result
