from __future__ import annotations

import numpy as np

from .mi import entropy, joint_state_codes


STATE_BITS = 9  # three 3-bit ring positions; enough to enumerate 8^3 = 512 states


def encode_state_bits(states: np.ndarray, n_cells: int = 8) -> np.ndarray:
    values = np.asarray(states, dtype=np.int64)
    if values.ndim == 1:
        values = values[None, :]
    bits_per_position = int(np.ceil(np.log2(n_cells)))
    bit_columns = []
    for position in values.T:
        for bit in range(bits_per_position - 1, -1, -1):
            bit_columns.append(((position >> bit) & 1).astype(np.int8))
    return np.stack(bit_columns, axis=1)


def decode_state_bits(bits: np.ndarray, n_cells: int = 8) -> np.ndarray:
    matrix = np.asarray(bits, dtype=np.int8)
    if matrix.ndim == 1:
        matrix = matrix[None, :]
    bits_per_position = int(np.ceil(np.log2(n_cells)))
    values = []
    for start in range(0, matrix.shape[1], bits_per_position):
        value = np.zeros(matrix.shape[0], dtype=np.int64)
        for bit in matrix[:, start : start + bits_per_position].T:
            value = (value << 1) | bit
        values.append(value)
    return np.stack(values, axis=1)


def state_bit_marginals(
    states: np.ndarray,
    n_cells: int = 8,
    weights: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    values = np.asarray(states, dtype=np.int64)
    bits = encode_state_bits(values, n_cells)
    if weights is None:
        probabilities = np.full(len(values), 1.0 / len(values))
    else:
        probabilities = np.asarray(weights, dtype=np.float64)
        probabilities = probabilities / probabilities.sum()
    bit_marginals = np.clip(
        probabilities @ bits, 1e-12, 1.0 - 1e-12
    )
    position_marginals = np.zeros((values.shape[1], n_cells), dtype=np.float64)
    for agent, position in enumerate(values.T):
        counts = np.bincount(
            position, weights=probabilities, minlength=n_cells
        ).astype(np.float64)
        position_marginals[agent] = counts / counts.sum()
    return bit_marginals, position_marginals


def _blocks(width: int, block_size: int) -> list[np.ndarray]:
    return [
        np.arange(start, min(start + block_size, width), dtype=np.int64)
        for start in range(0, width, block_size)
    ]


def coarse_signatures(
    states: np.ndarray, block_size: int, n_cells: int = 8
) -> np.ndarray:
    """C: replace every contiguous bit block with its deterministic mode.

    The measured state remains the three-position state. The 9-bit encoding is
    only the finite representation on which block-decimation is defined, which
    permits five non-trivial aggressiveness values while preserving exact
    512-state enumeration for MI.
    """
    bits = encode_state_bits(states, n_cells)
    signatures = np.zeros((bits.shape[0], len(_blocks(STATE_BITS, block_size))), dtype=np.int8)
    for block_index, block in enumerate(_blocks(STATE_BITS, block_size)):
        # Ties resolve to 0, making C deterministic and reproducible.
        signatures[:, block_index] = (bits[:, block].sum(axis=1) > len(block) / 2).astype(
            np.int8
        )
    return signatures


def signature_codes(signatures: np.ndarray) -> np.ndarray:
    codes = np.zeros(signatures.shape[0], dtype=np.int64)
    for column in np.asarray(signatures, dtype=np.int64).T:
        codes = (codes << 1) | column
    return codes


class NoisePaddedReset:
    """R = E o C, with independent marginal noise in erased bit positions."""

    def __init__(
        self,
        reference_states: np.ndarray,
        n_cells: int = 8,
        seed: int = 0,
        reference_probabilities: np.ndarray | None = None,
    ) -> None:
        self.n_cells = n_cells
        self.reference_states = np.asarray(reference_states, dtype=np.int64)
        self.bit_marginals, self.position_marginals = state_bit_marginals(
            self.reference_states, n_cells, weights=reference_probabilities
        )
        self.rng = np.random.default_rng(seed)

    def entropy_shed(self, block_size: int) -> float:
        before = entropy(
            joint_state_codes(self.reference_states, self.n_cells),
            alphabet_size=self.n_cells ** self.reference_states.shape[1],
        )
        after = entropy(
            signature_codes(coarse_signatures(self.reference_states, block_size, self.n_cells))
        )
        return float(before - after)

    def exact_kernel(self, block_size: int) -> np.ndarray:
        """Return the exact 512 x 512 transition kernel for E o C."""
        n_states = self.n_cells**3
        all_states = np.stack(
            [
                np.array(
                    [
                        (code // (self.n_cells**2)) % self.n_cells,
                        (code // self.n_cells) % self.n_cells,
                        code % self.n_cells,
                    ],
                    dtype=np.int64,
                )
                for code in range(n_states)
            ]
        )
        input_bits = encode_state_bits(all_states, self.n_cells)
        output_bits = input_bits.copy()
        blocks = _blocks(STATE_BITS, block_size)
        kernel = np.zeros((n_states, n_states), dtype=np.float64)

        for input_code in range(n_states):
            modes = [
                int(input_bits[input_code, block].sum() > len(block) / 2)
                for block in blocks
            ]
            probabilities = np.ones(n_states, dtype=np.float64)
            for block, mode in zip(blocks, modes):
                probabilities *= (output_bits[:, block[0]] == mode)
                for bit_index in block[1:]:
                    probability_one = self.bit_marginals[bit_index]
                    probabilities *= np.where(
                        output_bits[:, bit_index] == 1,
                        probability_one,
                        1.0 - probability_one,
                    )
            row_sum = probabilities.sum()
            if row_sum <= 0:
                raise AssertionError("reset kernel row lost all probability mass")
            kernel[input_code] = probabilities / row_sum
        if not np.allclose(kernel.sum(axis=1), 1.0, atol=1e-12):
            raise AssertionError("reset kernel is not row stochastic")
        return kernel

    def exact_entropy_shed(
        self, state_distribution: np.ndarray, block_size: int
    ) -> float:
        probabilities = np.asarray(state_distribution, dtype=np.float64)
        probabilities = probabilities / probabilities.sum()
        n_states = self.n_cells**3
        all_states = np.stack(
            [
                np.array(
                    [
                        (code // (self.n_cells**2)) % self.n_cells,
                        (code // self.n_cells) % self.n_cells,
                        code % self.n_cells,
                    ]
                )
                for code in range(n_states)
            ]
        )
        signatures = signature_codes(
            coarse_signatures(all_states, block_size, self.n_cells)
        )
        coarse_probability = np.bincount(
            signatures, weights=probabilities, minlength=int(signatures.max()) + 1
        )
        before = -float(
            np.sum(probabilities[probabilities > 0] * np.log(probabilities[probabilities > 0]))
        )
        after = -float(
            np.sum(
                coarse_probability[coarse_probability > 0]
                * np.log(coarse_probability[coarse_probability > 0])
            )
        )
        return before - after

    def transform(
        self,
        states: np.ndarray,
        block_size: int,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        values = np.asarray(states, dtype=np.int64)
        if values.ndim == 1:
            values = values[None, :]
        generator = rng or self.rng
        bits = encode_state_bits(values, self.n_cells)
        blocks = _blocks(STATE_BITS, block_size)
        padded = bits.copy()
        for block in blocks:
            mode = (bits[:, block].sum(axis=1) > len(block) / 2).astype(np.int8)
            padded[:, block[0]] = mode
            if len(block) > 1:
                erased = block[1:]
                padded[:, erased] = (
                    generator.random((len(values), len(erased)))
                    < self.bit_marginals[erased][None, :]
                ).astype(np.int8)
        decoded = decode_state_bits(padded, self.n_cells)
        invalid = (decoded < 0) | (decoded >= self.n_cells)
        for agent in range(decoded.shape[1]):
            invalid_rows = np.flatnonzero(invalid[:, agent])
            if len(invalid_rows):
                decoded[invalid_rows, agent] = generator.choice(
                    self.n_cells,
                    size=len(invalid_rows),
                    p=self.position_marginals[agent],
                )
        return decoded

    def transform_one(
        self, state: np.ndarray, block_size: int, rng: np.random.Generator
    ) -> np.ndarray:
        return self.transform(state, block_size, rng)[0]


def identity_reset_sanity(
    states: np.ndarray, n_cells: int = 8
) -> dict[str, float]:
    """A reversible C must preserve every joint and self dependency exactly."""
    values = np.asarray(states, dtype=np.int64)
    result = {
        "joint_mi_nats": float(
            __import__("pilot.mi", fromlist=["mutual_information"]).mutual_information(
                joint_state_codes(values, n_cells),
                joint_state_codes(values, n_cells),
                n_cells**3,
                n_cells**3,
                miller_madow=False,
            )
        )
    }
    result["joint_entropy_nats"] = entropy(
        joint_state_codes(values, n_cells), alphabet_size=n_cells**3
    )
    return result
