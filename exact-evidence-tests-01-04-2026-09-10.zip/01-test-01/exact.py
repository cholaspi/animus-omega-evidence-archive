from __future__ import annotations

import itertools

import numpy as np

from .environment import RingCoverageEnvironment
from .mi import relational_persistence_from_joint_distribution
from .policy import FrozenPolicy


def decode_all_states(n_agents: int = 3, n_cells: int = 8) -> np.ndarray:
    return np.asarray(
        list(itertools.product(range(n_cells), repeat=n_agents)), dtype=np.int64
    )


def one_step_kernel(
    policy: FrozenPolicy,
    partner_shuffle: bool = False,
    permutation_index: int | None = None,
) -> np.ndarray:
    """Enumerate all 512 states and all 3^3 joint actions exactly."""
    env = policy.env
    states = decode_all_states(env.n_agents, env.n_cells)
    n_states = len(states)
    kernel = np.zeros((n_states, n_states), dtype=np.float64)
    action_tuples = list(itertools.product(range(env.n_actions), repeat=env.n_agents))

    for code, state in enumerate(states):
        action_probabilities = policy.action_probabilities(
            state,
            partner_shuffle=partner_shuffle,
            permutation_index=permutation_index,
        )
        for action_tuple in action_tuples:
            probability = float(
                np.prod(
                    [
                        action_probabilities[agent, action]
                        for agent, action in enumerate(action_tuple)
                    ]
                )
            )
            next_state = env.transition(state, np.asarray(action_tuple, dtype=np.int64))
            next_code = int(
                next_state[0] * env.n_cells**2
                + next_state[1] * env.n_cells
                + next_state[2]
            )
            kernel[code, next_code] += probability
    kernel /= kernel.sum(axis=1, keepdims=True)
    return kernel


def rollout_kernel(step_kernel: np.ndarray, episode_steps: int) -> np.ndarray:
    kernel = np.linalg.matrix_power(step_kernel, episode_steps)
    kernel /= kernel.sum(axis=1, keepdims=True)
    return kernel


def end_distributions_after_cycles(
    rollout: np.ndarray,
    reset: np.ndarray,
    cycles: int,
) -> np.ndarray:
    """One row per possible initial state, after exactly `cycles` cycles."""
    if cycles < 1:
        raise ValueError("cycles must be positive")
    cycle_kernel = rollout @ reset
    if cycles == 1:
        result = rollout.copy()
    else:
        result = np.linalg.matrix_power(cycle_kernel, cycles - 1) @ rollout
    result /= result.sum(axis=1, keepdims=True)
    return result


def exact_end_seed_joint(
    end_distribution: np.ndarray, reset_kernel: np.ndarray
) -> np.ndarray:
    distribution = np.asarray(end_distribution, dtype=np.float64)
    distribution = distribution / distribution.sum()
    return distribution[:, None] * reset_kernel


def exact_relational_persistence(
    end_distribution: np.ndarray, reset_kernel: np.ndarray
) -> dict[str, float | list[float] | int | str]:
    return relational_persistence_from_joint_distribution(
        exact_end_seed_joint(end_distribution, reset_kernel)
    )


def exact_cross_run_independent_persistence(
    end_distribution: np.ndarray, seed_distribution: np.ndarray
) -> dict[str, float | list[float] | int | str]:
    joint = np.outer(
        end_distribution / end_distribution.sum(),
        seed_distribution / seed_distribution.sum(),
    )
    return relational_persistence_from_joint_distribution(joint)
