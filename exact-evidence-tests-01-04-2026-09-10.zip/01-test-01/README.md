# Multi-Agent Reset-Persistence Pilot

This repository contains the tiny, exactly enumerable pilot only. It trains two
small shared-parameter policies on an 8-cell cooperative coverage task, freezes
their weights, and then computes reset persistence over the complete
`8^3 = 512` joint-state space.

## Run

From the repository root:

```bash
python run_pilot.py
```

The default command enforces the preregistered minimums:

- 3 agents, 8 ring cells, and 16 environment steps per cycle
- 50 reset cycles
- five non-trivial reset block sizes
- 1,024 exact null sign assignments from 10 matched training pairs
- exact enumeration of all 512 joint states and all 27 joint actions per state

For a fast development-only smoke check:

```bash
python run_pilot.py --quick
```

The quick mode is intentionally below the acceptance sample counts and must not
be used to report a detection threshold.

## What is exact

Training is stochastic REINFORCE, but the measured phase is not a sampled MI
estimator. After training, weights are frozen and the policy is compiled into a
transition kernel by enumerating:

1. all 512 joint position states;
2. all 27 joint actions at each state;
3. the exact 16-step rollout kernel;
4. the exact 512 by 512 noise-padded reset kernel; and
5. the complete 512 by 512 joint probability table for `(S_end, S_seed)`.

Mutual information is evaluated directly from that complete probability table.
No KSG, CKA, CSSR, nearest-neighbor estimator, or Monte Carlo MI estimate is
used. The optional empirical Miller-Madow implementation is retained as a
diagnostic utility, not used for the reported ground-truth MI.

## Coupling and its ablation

Both regimes use the same MLP sizes and auxiliary-head output dimensions.

- **Isolated:** the auxiliary head predicts the acting agent's own current
  position in every output slot. Its feedback therefore carries no partner
  information.
- **Coupled:** the auxiliary head predicts all agents' next positions. The
  resulting probability vector is concatenated back into the policy input
  before the action logits are produced.

The run performs an inference-time ablation by replacing the coupled
partner-prediction vector with uniform noise over ring positions. It reports the
mean and maximum absolute change in action probabilities over all 512 states.
If the mean change is at or below `1e-6`, the run raises an error instead of
claiming that coupling affected behavior.

## Reset definition

The measured three-position state is represented losslessly by nine bits
(three bits per ring position). `C` partitions that finite vector into
contiguous blocks of size `b` and retains each block mode. `E` restores the
block aggregate at the block anchor and independently noise-pads every erased
bit from that coordinate's marginal. The coordinate marginals are calculated
exactly from the pooled isolated and coupled pre-reset end-state distribution,
then held fixed and shared by both regimes. The tiling baseline is deliberately
not used.

## Outputs

The command writes:

- `pilot/output/results.json`
- `pilot/output/entropy_shed_vs_b.png`
- `pilot/output/null_delta_histogram.png`

The terminal report prints the actual values for:

- entropy shed at every `b`, for both regimes;
- analytic and computed MI for a perfectly copied fair bit, plus the absolute
  difference;
- identity-reset `P_rel`, joint MI, its theoretical maximum, and retention
  fraction for both regimes;
- mean and maximum action-probability change under the coupling ablation;
- mean, standard deviation, and 99th percentile for both null constructions;
- the final threshold in nats.

## Interpreting the nulls

- **Cross-run independence sanity:** combines an end-state marginal from one
  exact run with an independent seed-state marginal from another. Exact
  independence makes its MI zero up to floating-point roundoff. This is a
  construction check, not the empirical threshold distribution.
- **Shuffled-partner null:** trains matched isolated/coupled policy pairs from
  the same initialization and random-number stream, swaps only the two partner
  feedback slots for each actor, and computes each pair's delta from exact
  kernels. Complete enumeration of all `2^10 = 1,024` paired sign assignments
  supplies the reported 99th-percentile threshold for the future confirmatory
  mean across 10 matched pairs.

For an identity reset, the formula in the specification implies
`P_rel = H(S) - sum_i H(s_i) = -TC(S)`, not a generally positive maximum. The
report therefore shows the identity `P_rel`, its exact `-TC(S)` expectation,
their difference, and the fact that joint MI reaches its entropy upper bound.

This pilot reports mechanism-test numbers only. It does not run or interpret
the later confirmatory coupled-vs-isolated comparison.
