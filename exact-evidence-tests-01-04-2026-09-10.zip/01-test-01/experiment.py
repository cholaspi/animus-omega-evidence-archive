from __future__ import annotations

import itertools
import json
import math
import time
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .config import PilotConfig
from .environment import RingCoverageEnvironment
from .exact import (
    exact_cross_run_independent_persistence,
    exact_relational_persistence,
    one_step_kernel,
    rollout_kernel,
)
from .mi import (
    run_known_mi_check,
)
from .policy import FrozenPolicy, train_policy
from .reset import NoisePaddedReset


def _weighted_entropy(probabilities: np.ndarray) -> float:
    values = np.asarray(probabilities, dtype=np.float64)
    values = values[values > 0]
    return float(-(values * np.log(values)).sum())


def _propagate_end_distribution(
    initial: np.ndarray,
    rollout: np.ndarray,
    reset: np.ndarray,
    cycles: int,
) -> np.ndarray:
    distribution = np.asarray(initial, dtype=np.float64)
    for cycle in range(cycles):
        end = distribution @ rollout
        if cycle < cycles - 1:
            distribution = end @ reset
    return end / end.sum()


def _solve_common_reset(
    reference_states: np.ndarray,
    uniform: np.ndarray,
    isolated_rollout: np.ndarray,
    coupled_rollout: np.ndarray,
    block_size: int,
    cycles: int,
    n_cells: int,
    seed: int,
    tolerance: float = 1e-9,
    max_iterations: int = 30,
) -> tuple[NoisePaddedReset, np.ndarray, dict[str, Any]]:
    """Solve pooled pre-reset marginals self-consistently for one block size."""
    reference_probability = 0.5 * (
        uniform @ isolated_rollout + uniform @ coupled_rollout
    )
    final_operator: NoisePaddedReset | None = None
    final_kernel: np.ndarray | None = None
    error = float("inf")
    for iteration in range(1, max_iterations + 1):
        operator = NoisePaddedReset(
            reference_states,
            n_cells,
            seed,
            reference_probabilities=reference_probability,
        )
        kernel = operator.exact_kernel(block_size)
        isolated_end = _propagate_end_distribution(
            uniform, isolated_rollout, kernel, cycles
        )
        coupled_end = _propagate_end_distribution(
            uniform, coupled_rollout, kernel, cycles
        )
        updated = 0.5 * (isolated_end + coupled_end)
        error = float(np.abs(updated - reference_probability).sum())
        final_operator, final_kernel = operator, kernel
        if error <= tolerance:
            break
        # Damping prevents mode/marginal feedback from oscillating.
        reference_probability = 0.5 * reference_probability + 0.5 * updated
    if final_operator is None or final_kernel is None:
        raise AssertionError("reset fixed-point solver did not initialize")
    # Rebuild once from the final pooled reference so the reported kernel and
    # reference marginals are exactly aligned.
    final_operator = NoisePaddedReset(
        reference_states,
        n_cells,
        seed,
        reference_probabilities=reference_probability,
    )
    final_kernel = final_operator.exact_kernel(block_size)
    return (
        final_operator,
        final_kernel,
        {
            "iterations": iteration,
            "l1_error": error,
            "tolerance": tolerance,
            "converged": error <= tolerance,
        },
    )


def _identity_metrics(end_distribution: np.ndarray) -> dict[str, Any]:
    identity = np.eye(len(end_distribution), dtype=np.float64)
    metrics = exact_relational_persistence(end_distribution, identity)
    entropy_nats = _weighted_entropy(end_distribution)
    metrics["end_entropy_nats"] = entropy_nats
    metrics["joint_mi_maximum_nats"] = entropy_nats
    metrics["joint_mi_retention_fraction"] = (
        float(metrics["joint_mi_nats"]) / entropy_nats if entropy_nats > 0 else 1.0
    )
    total_correlation = float(metrics["self_mi_nats"]) - entropy_nats
    expected_p_rel = -total_correlation
    metrics["total_correlation_nats"] = total_correlation
    metrics["expected_identity_p_rel_nats"] = expected_p_rel
    metrics["identity_p_rel_absolute_error_nats"] = abs(
        float(metrics["p_rel_nats"]) - expected_p_rel
    )
    return metrics


def _summarize(values: np.ndarray) -> dict[str, float | int]:
    samples = np.asarray(values, dtype=np.float64)
    return {
        "n": int(len(samples)),
        "mean_nats": float(samples.mean()),
        "std_nats": float(samples.std(ddof=1)) if len(samples) > 1 else 0.0,
        "min_nats": float(samples.min()),
        "max_nats": float(samples.max()),
        "p50_nats": float(np.percentile(samples, 50)),
        "p95_nats": float(np.percentile(samples, 95)),
        "p99_nats": float(np.percentile(samples, 99)),
    }


def _plot_entropy(
    block_sizes: list[int],
    entropy_shed: dict[str, dict[str, float]],
    output: Path,
) -> None:
    figure, axis = plt.subplots(figsize=(7.5, 4.5))
    for regime, values in entropy_shed.items():
        axis.plot(
            block_sizes,
            [values[str(block)] for block in block_sizes],
            marker="o",
            linewidth=2,
            label=regime.capitalize(),
        )
    axis.axhline(0.0, color="black", linewidth=1)
    axis.set_xlabel("Coarse-grain block size b")
    axis.set_ylabel("H(S) - H(C(S)) (nats)")
    axis.set_title("Deterministic coarse-graining entropy shed")
    axis.legend()
    axis.grid(alpha=0.25)
    figure.tight_layout()
    figure.savefig(output, dpi=180)
    plt.close(figure)


def _plot_null(
    cross_run: np.ndarray,
    shuffled_partner: np.ndarray,
    threshold: float,
    output: Path,
) -> None:
    figure, axis = plt.subplots(figsize=(8.2, 4.8))
    axis.hist(
        shuffled_partner,
        bins=40,
        alpha=0.72,
        label="Shuffled-partner paired sign-flip null",
        color="#3957a5",
    )
    axis.hist(
        cross_run,
        bins=20,
        alpha=0.55,
        label="Exact independence construction sanity",
        color="#d28b26",
    )
    axis.axvline(
        threshold,
        color="#b4202a",
        linestyle="--",
        linewidth=2,
        label=f"99th percentile = {threshold:.6g} nats",
    )
    axis.axvline(0.0, color="black", linewidth=1)
    axis.set_xlabel("Null interaction Δ (nats)")
    axis.set_ylabel("Count")
    axis.set_title("Null distribution of coupled-minus-isolated persistence")
    axis.legend()
    axis.grid(axis="y", alpha=0.2)
    figure.tight_layout()
    figure.savefig(output, dpi=180)
    plt.close(figure)


def run(config: PilotConfig, allow_small_debug_run: bool = False) -> dict[str, Any]:
    if not allow_small_debug_run:
        config.validate()
    start_time = time.time()
    np.random.seed(config.seed)

    env = RingCoverageEnvironment(
        n_cells=config.n_cells,
        n_agents=config.n_agents,
        target_cells=config.target_cells,
    )
    policy_pairs: list[
        tuple[FrozenPolicy, FrozenPolicy, list[float], list[float], int]
    ] = []
    for pair_index in range(config.null_training_pairs):
        pair_seed = config.seed + 1000 + pair_index
        # Same seed means matched initialization, environment starts, and
        # categorical random-number stream. Only the auxiliary target differs.
        isolated_model, isolated_rewards = train_policy(
            "isolated",
            env,
            pair_seed,
            config.train_episodes,
            config.learning_rate,
            config.hidden_size,
            config.entropy_bonus,
            config.auxiliary_weight,
            config.episode_steps,
        )
        coupled_model, coupled_rewards = train_policy(
            "coupled",
            env,
            pair_seed,
            config.train_episodes,
            config.learning_rate,
            config.hidden_size,
            config.entropy_bonus,
            config.auxiliary_weight,
            config.episode_steps,
        )
        policy_pairs.append(
            (
                FrozenPolicy.compile("isolated", env, isolated_model),
                FrozenPolicy.compile("coupled", env, coupled_model),
                isolated_rewards,
                coupled_rewards,
                pair_seed,
            )
        )

    isolated, coupled, isolated_rewards, coupled_rewards, primary_seed = policy_pairs[0]

    # One-step kernels enumerate 512 states x 27 joint actions exactly.
    isolated_step = one_step_kernel(isolated)
    coupled_step = one_step_kernel(coupled)
    isolated_rollout = rollout_kernel(isolated_step, config.episode_steps)
    coupled_rollout = rollout_kernel(coupled_step, config.episode_steps)

    # The complete state list is weighted by a self-consistent pooled pre-reset
    # distribution at the middle block size. This defines one common marginal
    # noise source for every regime, training pair, and b value.
    reference_states = np.asarray(
        [
            [a, b, c]
            for a in range(config.n_cells)
            for b in range(config.n_cells)
            for c in range(config.n_cells)
        ],
        dtype=np.int64,
    )
    uniform = np.full(config.n_cells**config.n_agents, 1.0 / (config.n_cells**config.n_agents))
    default_block = config.reset_block_sizes[len(config.reset_block_sizes) // 2]
    reset, solved_default_reset, reset_reference = _solve_common_reset(
        reference_states,
        uniform,
        isolated_rollout,
        coupled_rollout,
        default_block,
        config.cycles_per_rollout,
        config.n_cells,
        config.seed + 41,
    )
    if not allow_small_debug_run and not reset_reference["converged"]:
        raise AssertionError(
            "pooled reset marginal fixed point did not converge: "
            f"L1 error={reset_reference['l1_error']}"
        )

    measured: dict[str, dict[str, Any]] = {"isolated": {}, "coupled": {}}
    entropy_shed: dict[str, dict[str, float]] = {"isolated": {}, "coupled": {}}
    reset_kernels: dict[int, np.ndarray] = {}
    for block_size in config.reset_block_sizes:
        reset_kernel = (
            solved_default_reset
            if block_size == default_block
            else reset.exact_kernel(block_size)
        )
        reset_kernels[block_size] = reset_kernel
        for regime, rollout in (
            ("isolated", isolated_rollout),
            ("coupled", coupled_rollout),
        ):
            end_distribution = _propagate_end_distribution(
                uniform, rollout, reset_kernel, config.cycles_per_rollout
            )
            measured[regime][str(block_size)] = exact_relational_persistence(
                end_distribution, reset_kernel
            )
            shed = reset.exact_entropy_shed(end_distribution, block_size)
            if shed <= 0:
                raise AssertionError(
                    f"entropy shed must be positive: regime={regime}, b={block_size}, value={shed}"
                )
            entropy_shed[regime][str(block_size)] = float(shed)

    identity = {
        "isolated": _identity_metrics(
            _propagate_end_distribution(
                uniform,
                isolated_rollout,
                np.eye(len(uniform)),
                config.cycles_per_rollout,
            )
        ),
        "coupled": _identity_metrics(
            _propagate_end_distribution(
                uniform,
                coupled_rollout,
                np.eye(len(uniform)),
                config.cycles_per_rollout,
            )
        ),
    }
    for regime, metrics in identity.items():
        retention = float(metrics["joint_mi_retention_fraction"])
        if abs(retention - 1.0) > 1e-12:
            raise AssertionError(
                f"identity reset failed for {regime}: MI retention={retention}"
            )
        if float(metrics["identity_p_rel_absolute_error_nats"]) > 1e-12:
            raise AssertionError(
                f"identity P_rel identity failed for {regime}: "
                f"error={metrics['identity_p_rel_absolute_error_nats']}"
            )

    mi_check = run_known_mi_check()
    default_reset = reset_kernels[default_block]

    # Build exact shuffled-partner deltas across independently trained,
    # seed-paired policy pairs. The null distribution is then generated by a
    # paired sign-flip randomization test, which is exchangeable under Δ=0.
    shuffled_pair_deltas: list[float] = []
    cross_run_controls: list[float] = []
    pair_details: list[dict[str, Any]] = []
    for pair_index, (
        pair_isolated,
        pair_coupled,
        pair_isolated_rewards,
        pair_coupled_rewards,
        pair_seed,
    ) in enumerate(policy_pairs):
        pair_isolated_rollout = rollout_kernel(
            one_step_kernel(pair_isolated), config.episode_steps
        )
        pair_coupled_rollout = rollout_kernel(
            one_step_kernel(pair_coupled), config.episode_steps
        )
        pair_shuffled_rollout = rollout_kernel(
            one_step_kernel(pair_coupled, partner_shuffle=True),
            config.episode_steps,
        )
        pair_iso_end = _propagate_end_distribution(
            uniform,
            pair_isolated_rollout,
            default_reset,
            config.cycles_per_rollout,
        )
        pair_coupled_end = _propagate_end_distribution(
            uniform,
            pair_coupled_rollout,
            default_reset,
            config.cycles_per_rollout,
        )
        pair_shuffled_end = _propagate_end_distribution(
            uniform,
            pair_shuffled_rollout,
            default_reset,
            config.cycles_per_rollout,
        )
        isolated_persistence = exact_relational_persistence(
            pair_iso_end, default_reset
        )
        shuffled_persistence = exact_relational_persistence(
            pair_shuffled_end, default_reset
        )
        shuffled_delta = float(shuffled_persistence["p_rel_nats"]) - float(
            isolated_persistence["p_rel_nats"]
        )
        shuffled_pair_deltas.append(shuffled_delta)
        independent_seed = pair_coupled_end @ default_reset
        cross_control = exact_cross_run_independent_persistence(
            pair_iso_end, independent_seed
        )
        cross_run_controls.append(float(cross_control["p_rel_nats"]))
        pair_details.append(
            {
                "pair_index": pair_index,
                "training_seed": pair_seed,
                "shuffled_partner_delta_nats": shuffled_delta,
                "coupling_ablation_mean_abs_change": (
                    pair_coupled.ablation_mean_abs_change
                ),
                "isolated_reward_last_25": float(
                    np.mean(pair_isolated_rewards[-25:])
                ),
                "coupled_reward_last_25": float(
                    np.mean(pair_coupled_rewards[-25:])
                ),
            }
        )

    sign_assignments = np.asarray(
        list(itertools.product((-1.0, 1.0), repeat=len(shuffled_pair_deltas))),
        dtype=np.float64,
    )
    if not allow_small_debug_run and len(sign_assignments) != config.null_seeds:
        raise AssertionError(
            "configured null count does not match complete sign enumeration"
        )
    pair_delta_array = np.asarray(shuffled_pair_deltas, dtype=np.float64)
    shuffled_partner_deltas = (sign_assignments * pair_delta_array).mean(axis=1)
    cross_run_deltas = np.resize(
        np.asarray(cross_run_controls, dtype=np.float64),
        len(sign_assignments),
    )

    threshold = float(np.percentile(shuffled_partner_deltas, 99))
    cross_summary = _summarize(cross_run_deltas)
    shuffled_summary = _summarize(shuffled_partner_deltas)
    center_tolerance = max(
        1e-12,
        3.0
        * float(shuffled_summary["std_nats"])
        / math.sqrt(config.null_seeds),
    )
    if (
        not allow_small_debug_run
        and abs(float(shuffled_summary["mean_nats"])) > center_tolerance
    ):
        raise AssertionError(
            "shuffled-partner null is not centered near zero: "
            f"mean={shuffled_summary['mean_nats']}, tolerance={center_tolerance}"
        )

    output = config.output_path()
    entropy_plot = output / "entropy_shed_vs_b.png"
    null_plot = output / "null_delta_histogram.png"
    _plot_entropy(config.reset_block_sizes, entropy_shed, entropy_plot)
    _plot_null(cross_run_deltas, shuffled_partner_deltas, threshold, null_plot)

    training = {
        "paired_training_runs": config.null_training_pairs,
        "paired_initialization_and_random_streams": True,
        "isolated": {
            "episodes": len(isolated_rewards),
            "mean_reward_first_25": float(np.mean(isolated_rewards[:25])),
            "mean_reward_last_25": float(np.mean(isolated_rewards[-25:])),
        },
        "coupled": {
            "episodes": len(coupled_rewards),
            "mean_reward_first_25": float(np.mean(coupled_rewards[:25])),
            "mean_reward_last_25": float(np.mean(coupled_rewards[-25:])),
        },
    }
    ablation = {
        "method": "replace only re-entering partner slots with uniform predictions; preserve each actor's own slot",
        "mean_absolute_action_probability_change": coupled.ablation_mean_abs_change,
        "maximum_absolute_action_probability_change": coupled.ablation_max_abs_change,
        "minimum_mean_change_across_training_pairs": float(
            min(pair[1].ablation_mean_abs_change for pair in policy_pairs)
        ),
        "trained_vs_compiled_max_abs_error": (
            coupled.forward_compile_max_abs_error
        ),
        "failure_threshold": 1e-6,
    }
    results: dict[str, Any] = {
        "threshold_nats": threshold,
        "threshold_source": (
            "99th percentile of the complete paired sign-flip null over "
            "exact shuffled-partner deltas"
        ),
        "entropy_shed_by_b": entropy_shed,
        "null_delta_stats": {
            "cross_run_independence_sanity": cross_summary,
            "shuffled_partner_paired_sign_flip": shuffled_summary,
        },
        "shuffled_partner_null_pair_deltas_nats": shuffled_pair_deltas,
        "training_pair_details": pair_details,
        "measured_relational_persistence": measured,
        "identity_reset_sanity": identity,
        "analytic_mi_check": mi_check,
        "coupling_ablation": ablation,
        "training": training,
        "config": config.to_dict(),
        "seeds": {
            "master": config.seed,
            "paired_training": [pair[4] for pair in policy_pairs],
            "primary_training": primary_seed,
            "reset": config.seed + 41,
            "null_sign_assignments": list(range(len(sign_assignments))),
        },
        "enumeration": {
            "joint_states": 512,
            "joint_actions_per_state": 27,
            "end_seed_table_shape": [512, 512],
            "mi": "exact probability enumeration; no sampled estimator",
            "reset_kernel": "exact 512x512 probability kernel",
            "null_randomization": (
                f"complete {len(sign_assignments)}-assignment paired sign-flip "
                "distribution over exact shuffled-partner deltas"
            ),
            "future_confirmatory_estimand": (
                "mean coupled-minus-isolated P_rel across 10 matched "
                "training pairs"
            ),
            "reset_marginal_reference": reset_reference,
        },
        "outputs": {
            "entropy_plot": str(entropy_plot),
            "null_histogram": str(null_plot),
            "results_json": str(output / "results.json"),
        },
        "elapsed_seconds": float(time.time() - start_time),
    }
    with (output / "results.json").open("w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2, sort_keys=True)
    return results


def print_acceptance_report(results: dict[str, Any]) -> None:
    print("\nACCEPTANCE CRITERIA — MEASURED VALUES")
    print("=" * 48)
    for regime, values in results["entropy_shed_by_b"].items():
        rendered = ", ".join(
            f"b={block}: {shed:.9f} nats" for block, shed in values.items()
        )
        print(f"Entropy shed ({regime}): {rendered}")

    mi = results["analytic_mi_check"]
    print(
        "Analytic MI check: "
        f"computed={mi['computed_nats']:.12f}, "
        f"expected={mi['analytic_nats']:.12f}, "
        f"|difference|={mi['absolute_error_nats']:.3e} nats"
    )
    for regime, metrics in results["identity_reset_sanity"].items():
        print(
            f"Identity reset ({regime}): "
            f"P_rel={metrics['p_rel_nats']:.9f} nats, "
            f"expected -TC={metrics['expected_identity_p_rel_nats']:.9f} nats, "
            f"|difference|={metrics['identity_p_rel_absolute_error_nats']:.3e}, "
            f"joint MI={metrics['joint_mi_nats']:.9f} / "
            f"maximum={metrics['joint_mi_maximum_nats']:.9f} nats, "
            f"retention={metrics['joint_mi_retention_fraction']:.12f}"
        )
    ablation = results["coupling_ablation"]
    print(
        "Coupling ablation: "
        f"mean |Δ action probability|="
        f"{ablation['mean_absolute_action_probability_change']:.9e}, "
        f"max={ablation['maximum_absolute_action_probability_change']:.9e}, "
        f"minimum paired-run mean="
        f"{ablation['minimum_mean_change_across_training_pairs']:.9e}, "
        f"trained/compiled max error="
        f"{ablation['trained_vs_compiled_max_abs_error']:.3e}, "
        f"required mean>{ablation['failure_threshold']:.1e}"
    )
    for condition, stats in results["null_delta_stats"].items():
        print(
            f"Null Δ ({condition}, n={stats['n']}): "
            f"mean={stats['mean_nats']:.9e}, std={stats['std_nats']:.9e}, "
            f"p99={stats['p99_nats']:.9e} nats"
        )
    enumeration = results["enumeration"]
    reset_reference = enumeration["reset_marginal_reference"]
    print(
        "Reset marginal fixed point: "
        f"converged={reset_reference['converged']}, "
        f"iterations={reset_reference['iterations']}, "
        f"L1 error={reset_reference['l1_error']:.3e}, "
        f"tolerance={reset_reference['tolerance']:.1e}"
    )
    print(
        "MI computation: "
        f"{enumeration['mi']}; {enumeration['joint_states']} joint states, "
        f"dense table {enumeration['end_seed_table_shape'][0]}x"
        f"{enumeration['end_seed_table_shape'][1]}."
    )
    print(f"\nDetection threshold: {results['threshold_nats']:.9f} nats")
    print(f"Results: {results['outputs']['results_json']}")
    print(f"Plots: {results['outputs']['entropy_plot']}, {results['outputs']['null_histogram']}")
