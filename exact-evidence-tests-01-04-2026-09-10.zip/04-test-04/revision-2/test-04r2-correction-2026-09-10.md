# Test 04 Revision 2 terminology correction

**Correction date:** 2026-09-10

The Test 04 Revision 2 report dated 2026-09-09 used the word
`preregistered` in two sentences describing the 60 seed-by-checkpoint arms
and six causal-coverage predicates.

That wording was inaccurate. Test 04 Revision 2 was prespecified under a
frozen protocol before its reserved seeds were accessed, but it was not
registered with an external registration service before execution.

The corrected report uses `prespecified under the frozen protocol` and
`prespecified causal-coverage predicates`. This correction changes no
protocol, source code, seed, checkpoint, result, exclusion, interpretation
boundary, or evidence status.

The corrected release manifest and checksum file identify the regenerated
report and this notice.