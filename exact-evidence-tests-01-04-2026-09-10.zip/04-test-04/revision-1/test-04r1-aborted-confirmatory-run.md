# Test 04 confirmatory execution status

**Status:** operationally aborted and scientifically incomplete  
**Date:** 2026-09-09  
**Frozen manifest digest:** `8a1abe53a80d51ea09b87940b4864199f1fd28556d41d3fcef156a7704af7fbb`

The one authorized confirmatory command began and atomically created
`confirmatory_output/confirmatory.started`. The execution then exceeded the
300-second command limit and was terminated before publishing any result.

No `results.json`, `summary.csv`, temporary result, or
`confirmatory.completed` marker exists. There is therefore no positive or
negative Test 04 result.

The permanent start marker must remain in place. The frozen run must not be
resumed or restarted, and reserved seeds 42000–42019 must be treated as burned.
Any replacement study requires a new preregistration, new previously unexecuted
reserved seeds, a newly frozen manifest, and an execution method with a
validated runtime budget.